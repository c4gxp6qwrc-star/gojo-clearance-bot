import os
from io import BytesIO

from PIL import Image
from pyzbar.pyzbar import decode as decode_barcodes

from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

TELEGRAM_BOT_TOKEN = os.getenv("BOT_TOKEN")

def build_links_from_code(code: str) -> str:
    home_depot_search = f"https://www.homedepot.com/s/{code}"
    google_search = f"https://www.google.com/search?q={code}+Home+Depot+clearance"

    text = (
        f"🔢 *Code detected:* `{code}`\n\n"
        f"🧡 *Home Depot search:*\n{home_depot_search}\n\n"
        f"🌐 *Google search:*\n{google_search}\n\n"
        "👉 Check your Home Depot app/in-store scanner for exact clearance price."
    )
    return text


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 Welcome to *GOJO Home Depot Clearance Helper Bot*!\n\n"
        "Send me a *barcode photo* or *type the barcode number*.",
        parse_mode="Markdown"
    )


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message.text.strip()
    if msg.isdigit() and 8 <= len(msg) <= 16:
        await update.message.reply_text(build_links_from_code(msg), parse_mode="Markdown")
    else:
        await update.message.reply_text("Send a barcode number or photo 😊")


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message

    if not msg.photo:
        return await msg.reply_text("Send a clear barcode photo.")

    photo = msg.photo[-1]
    file = await photo.get_file()
    buf = BytesIO()
    await file.download_to_memory(buf)
    buf.seek(0)

    image = Image.open(buf)
    decoded = decode_barcodes(image)

    if not decoded:
        return await msg.reply_text("Couldn't read barcode. Try a closer photo.")

    code = decoded[0].data.decode("utf-8")
    await msg.reply_text(build_links_from_code(code), parse_mode="Markdown")


def main():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.run_polling()


if __name__ == "__main__":
    main()
